var enumcom_1_1thalmic_1_1myo_1_1_pose =
[
    [ "DOUBLE_TAP", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#a111f4ddff6156ba0ab5b53fe7e4abc3f", null ],
    [ "FINGERS_SPREAD", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#a68d6ac19706f96153eb7daa24c3e41fe", null ],
    [ "FIST", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#a4257b033a304f6ae268745f88f6c88ee", null ],
    [ "REST", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#a19fdb149b91add797d1faf8ab94007f2", null ],
    [ "UNKNOWN", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#abbc10885a1b50c4e1688e83edee531f6", null ],
    [ "WAVE_IN", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#accc08bd0249d015c2ba53b31c27032e6", null ],
    [ "WAVE_OUT", "enumcom_1_1thalmic_1_1myo_1_1_pose.html#ae31cd3c6c04e6f2778f208c28d59ba99", null ]
];
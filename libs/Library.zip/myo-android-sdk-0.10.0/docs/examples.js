var examples =
[
    [ "BackgroundService.java", "_background_service_8java-example.html", null ],
    [ "HelloWorldActivity.java", "_hello_world_activity_8java-example.html", null ],
    [ "MultipleMyosActivity.java", "_multiple_myos_activity_8java-example.html", null ],
    [ "MyoGlassService.java", "_myo_glass_service_8java-example.html", null ]
];
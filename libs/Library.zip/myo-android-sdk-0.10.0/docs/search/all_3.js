var searchData=
[
  ['firmwareversion',['FirmwareVersion',['../classcom_1_1thalmic_1_1myo_1_1_firmware_version.html',1,'com::thalmic::myo']]]
];

var searchData=
[
  ['vector3',['Vector3',['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#a86ffda4345a83df66e7e92c828b74fe4',1,'com.thalmic.myo.Vector3.Vector3()'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#ae4e7099f29c0aa95246f70c5d0f2da71',1,'com.thalmic.myo.Vector3.Vector3(Vector3 other)'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#ac2eb8c6eb6e30b31815f6398f9d770cd',1,'com.thalmic.myo.Vector3.Vector3(double x, double y, double z)']]],
  ['vibrate',['vibrate',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#a5223ccf9bf186862e851432964d3a89d',1,'com::thalmic::myo::Myo']]]
];

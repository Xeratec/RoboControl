var searchData=
[
  ['vector3',['Vector3',['../classcom_1_1thalmic_1_1myo_1_1_vector3.html',1,'com::thalmic::myo']]],
  ['vibrationtype',['VibrationType',['../enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html',1,'com::thalmic::myo::Myo']]]
];

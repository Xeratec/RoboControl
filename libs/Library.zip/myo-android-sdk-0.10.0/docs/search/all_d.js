var searchData=
[
  ['release_20notes_20and_20known_20issues',['Release Notes And Known Issues',['../release-notes.html',1,'']]],
  ['removelistener',['removeListener',['../classcom_1_1thalmic_1_1myo_1_1_hub.html#a050241bd061ecce16fe6b1c874c10fa3',1,'com::thalmic::myo::Hub']]],
  ['requestrssi',['requestRssi',['../classcom_1_1thalmic_1_1myo_1_1_myo.html#aaa7ba8348b783b0c46e7a2d9b5407389',1,'com::thalmic::myo::Myo']]],
  ['roll',['roll',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a87e1d1420fce31bee3a6372bbaf3bd71',1,'com::thalmic::myo::Quaternion']]]
];

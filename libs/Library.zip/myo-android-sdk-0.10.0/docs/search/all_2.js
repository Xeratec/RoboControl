var searchData=
[
  ['emgmode',['EmgMode',['../enumcom_1_1thalmic_1_1myo_1_1_control_command_1_1_emg_mode.html',1,'com::thalmic::myo::ControlCommand']]]
];

var searchData=
[
  ['z',['z',['../classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a5eb6db33856f95456dcaf0ec9c997c4e',1,'com.thalmic.myo.Quaternion.z()'],['../classcom_1_1thalmic_1_1myo_1_1_vector3.html#a47ab23277d96203501b506c20e0b1fea',1,'com.thalmic.myo.Vector3.z()']]]
];

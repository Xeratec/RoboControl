var enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy =
[
    [ "NONE", "enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy.html#a1010336224e135638cca8450efa60de6", null ],
    [ "STANDARD", "enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy.html#ab8f5602f2063ae0e98751390379bbeb2", null ]
];
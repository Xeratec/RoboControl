var classcom_1_1thalmic_1_1myo_1_1_hub =
[
    [ "LockingPolicy", "enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy.html", "enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy" ],
    [ "addListener", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a88531755245ea6ceac9ed4b91fd34f49", null ],
    [ "attachByMacAddress", "classcom_1_1thalmic_1_1myo_1_1_hub.html#ac6546069d104680284b70a4d9009d9dc", null ],
    [ "attachToAdjacentMyo", "classcom_1_1thalmic_1_1myo_1_1_hub.html#aa1feeb9e92747919fbd7e01c134215fd", null ],
    [ "attachToAdjacentMyos", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a543043fa4ac308830ad8e9dc14cead24", null ],
    [ "detach", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a668d3d761b3d77826d6778dfd9bc9faa", null ],
    [ "getConnectedDevices", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a3c86161e09805b643969789d0a761861", null ],
    [ "getLockingPolicy", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a8caa26655706cd2412ab5a90dd55d839", null ],
    [ "getMyoAttachAllowance", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a91afe16d97aa296654fc41ecd28c5b0d", null ],
    [ "init", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a6630d2df92577e8e6c5c27673a6fc8ba", null ],
    [ "init", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a91352ca197594c1cd447755d83d0b4e1", null ],
    [ "isSendingUsageData", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a8f56021d0e2657650176d94006ef594b", null ],
    [ "now", "classcom_1_1thalmic_1_1myo_1_1_hub.html#af8d9a02314b930edf468b972ca9abc06", null ],
    [ "removeListener", "classcom_1_1thalmic_1_1myo_1_1_hub.html#a050241bd061ecce16fe6b1c874c10fa3", null ],
    [ "setLockingPolicy", "classcom_1_1thalmic_1_1myo_1_1_hub.html#adb1633c644c16f54d8e8effec9fbf8f0", null ],
    [ "setMyoAttachAllowance", "classcom_1_1thalmic_1_1myo_1_1_hub.html#add2637b2598503002b3376090cddb797", null ],
    [ "setSendUsageData", "classcom_1_1thalmic_1_1myo_1_1_hub.html#ad35209eef6c1faf0a0bfcf27e429ed33", null ],
    [ "shutdown", "classcom_1_1thalmic_1_1myo_1_1_hub.html#abcf3aa86d0d08d861d03f721b4de48e1", null ]
];
var hierarchy =
[
    [ "com.thalmic.myo.Arm", "enumcom_1_1thalmic_1_1myo_1_1_arm.html", null ],
    [ "com.thalmic.myo.DeviceListener", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html", [
      [ "com.thalmic.myo.AbstractDeviceListener", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html", null ]
    ] ],
    [ "com.thalmic.myo.ControlCommand.EmgMode", "enumcom_1_1thalmic_1_1myo_1_1_control_command_1_1_emg_mode.html", null ],
    [ "com.thalmic.myo.FirmwareVersion", "classcom_1_1thalmic_1_1myo_1_1_firmware_version.html", null ],
    [ "com.thalmic.myo.Hub", "classcom_1_1thalmic_1_1myo_1_1_hub.html", null ],
    [ "com.thalmic.myo.Hub.LockingPolicy", "enumcom_1_1thalmic_1_1myo_1_1_hub_1_1_locking_policy.html", null ],
    [ "com.thalmic.myo.Myo", "classcom_1_1thalmic_1_1myo_1_1_myo.html", null ],
    [ "com.thalmic.myo.Pose", "enumcom_1_1thalmic_1_1myo_1_1_pose.html", null ],
    [ "com.thalmic.myo.Quaternion", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html", null ],
    [ "com.thalmic.myo.ClassifierEvent.Type", "enumcom_1_1thalmic_1_1myo_1_1_classifier_event_1_1_type.html", null ],
    [ "com.thalmic.myo.Myo.UnlockType", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_unlock_type.html", null ],
    [ "com.thalmic.myo.Vector3", "classcom_1_1thalmic_1_1myo_1_1_vector3.html", null ],
    [ "com.thalmic.myo.Myo.VibrationType", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html", null ],
    [ "com.thalmic.myo.XDirection", "enumcom_1_1thalmic_1_1myo_1_1_x_direction.html", null ]
];
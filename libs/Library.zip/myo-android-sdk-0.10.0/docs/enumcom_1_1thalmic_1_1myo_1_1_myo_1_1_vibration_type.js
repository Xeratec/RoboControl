var enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type =
[
    [ "LONG", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html#a0fbec3617a7c10de6ea3c1cf0d68b76e", null ],
    [ "MEDIUM", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html#ace966320edf85eeb8392815696ad35db", null ],
    [ "SHORT", "enumcom_1_1thalmic_1_1myo_1_1_myo_1_1_vibration_type.html#af285cc4b77d2ec3524176bfe6aa12426", null ]
];
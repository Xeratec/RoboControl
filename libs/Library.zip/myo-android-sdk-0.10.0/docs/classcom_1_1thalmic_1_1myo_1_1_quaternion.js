var classcom_1_1thalmic_1_1myo_1_1_quaternion =
[
    [ "Quaternion", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#afb17c372d8719279738b490f541469d9", null ],
    [ "Quaternion", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ac0653fe3d6c36525c0502b86b3276075", null ],
    [ "Quaternion", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a90139a4f3cf6acdb571364b2fc43be08", null ],
    [ "equals", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a52f8c2ad2d4973d9919be47bd915ad9c", null ],
    [ "hashCode", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a72c2bc0e225962df0889677e4344aa27", null ],
    [ "inverse", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ae578877d7d4c63461f4bce1e7bb440a1", null ],
    [ "length", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#adb9c229318d2c05b047b256b1a65fd12", null ],
    [ "multiply", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a235bcc2ae797a156969ce56d29bc5394", null ],
    [ "normalized", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#abb72338e75f4b5276e7320e2cd9c5571", null ],
    [ "set", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a69cf4e89ac241b80144c054bb34f7ec5", null ],
    [ "toString", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ac5a448012f0c419e37e15d9a6af085a8", null ],
    [ "w", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#ab25d69ea31107cf36a642a58b9246c45", null ],
    [ "x", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#aa4784eecbb2dfbef14c773b68be254f7", null ],
    [ "y", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a9ce473d7cb193c075f1710360a73185b", null ],
    [ "z", "classcom_1_1thalmic_1_1myo_1_1_quaternion.html#a5eb6db33856f95456dcaf0ec9c997c4e", null ]
];
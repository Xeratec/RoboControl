var interfacecom_1_1thalmic_1_1myo_1_1_device_listener =
[
    [ "onAccelerometerData", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a37db35a7098919daf554c2dafde3fc03", null ],
    [ "onArmSync", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a1c00adb39cc0a43b8ea752aa8a687bf5", null ],
    [ "onArmUnsync", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a8c979bbbb4aec2d96d4c69e4e96f9f55", null ],
    [ "onAttach", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a6aeee67621cc8d2d94c58afef3a22f0b", null ],
    [ "onConnect", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a5b0f99d27d7754f6252a58351240acc7", null ],
    [ "onDetach", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a4edd67a07428a29f4d84fc70a80c4ea6", null ],
    [ "onDisconnect", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a810d53df69b116c05041b77df0f899c7", null ],
    [ "onGyroscopeData", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a44c287eaf897b2227ddbeb9dd31e4110", null ],
    [ "onLock", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#aac97545c3cbb2fd9cfde1f42cb586893", null ],
    [ "onOrientationData", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#aa133cfe7730afafc88d2e50127abdfcc", null ],
    [ "onPose", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a9bb88626720580711c12d1da1c8b08df", null ],
    [ "onRssi", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#a4dbd2eaec503ad6273bd650353ae0a00", null ],
    [ "onUnlock", "interfacecom_1_1thalmic_1_1myo_1_1_device_listener.html#af6477d2f7827964427e02d9932111408", null ]
];
var classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener =
[
    [ "onAccelerometerData", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a66e1c4cf5f9292a57cfe17b775269764", null ],
    [ "onArmSync", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a0cf91045b42a3dca2e699f26e56b9afb", null ],
    [ "onArmUnsync", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#ab5c8995bc1d0c552465c339111cec3d8", null ],
    [ "onAttach", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a91d93ba06e8e3056f8fe9489e2813304", null ],
    [ "onConnect", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a734c5fcf03025da8ab2a62daa490f44f", null ],
    [ "onDetach", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a3e5dd26f66321f8df2df99d51de2ea4b", null ],
    [ "onDisconnect", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a4dae3026a90c674bbb71e17abaf78d6a", null ],
    [ "onGyroscopeData", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#aa7633f697ecab99b5bf3c7b3babe4a4c", null ],
    [ "onLock", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a9dddf1f2c3e9b939876bff500fd1f13a", null ],
    [ "onOrientationData", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a45e558b824c5ea8412153502548711a7", null ],
    [ "onPose", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#a628389118ecae6cf17099c8f6f46baa8", null ],
    [ "onRssi", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#acbd9b7ecb7f109c076f5cdd0ef5d6bb0", null ],
    [ "onUnlock", "classcom_1_1thalmic_1_1myo_1_1_abstract_device_listener.html#ab71fc9ced3a7d16457efd874b25df7c9", null ]
];